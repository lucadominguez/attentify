'use strict';
// LOCAL SECRET — gitignored. Holds the bundled OpenRouter key so the extension's AI
// works out of the box. Copy config.example.js → config.js and fill in the key.
// Loaded by background.js via importScripts before any AI call.
self.ATTENTIFY_BUNDLED_OPENROUTER_KEY = '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';
